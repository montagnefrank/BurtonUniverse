<?php

$master = array(
    'LytigaPro-Light__eot' => 'http://envato.pixevil.com/volta/resources/fonts/lytiga-pro/LytigaPro-Light.eot',
    'LytigaPro-Light__svg' => 'http://envato.pixevil.com/volta/resources/fonts/lytiga-pro/LytigaPro-Light.svg',
    'LytigaPro-Light__ttf' => 'http://envato.pixevil.com/volta/resources/fonts/lytiga-pro/LytigaPro-Light.ttf',
    'LytigaPro-Light__woff' => 'http://envato.pixevil.com/volta/resources/fonts/lytiga-pro/LytigaPro-Light.woff',
    'LytigaPro-Light__woff2' => 'http://envato.pixevil.com/volta/resources/fonts/lytiga-pro/LytigaPro-Light.woff2',
    'ProximaNova-Bold__svg' => 'http://envato.pixevil.com/volta/resources/fonts/proxima-nova/ProximaNova-Bold.svg',
    'ProximaNova-Bold__ttf' => 'http://envato.pixevil.com/volta/resources/fonts/proxima-nova/ProximaNova-Bold.ttf',
    'ProximaNova-Bold__woff' => 'http://envato.pixevil.com/volta/resources/fonts/proxima-nova/ProximaNova-Bold.woff',
    'ProximaNova-Bold__woff2' => 'http://envato.pixevil.com/volta/resources/fonts/proxima-nova/ProximaNova-Bold.woff2',
    'ProximaNova-Extrabld__svg' => 'http://envato.pixevil.com/volta/resources/fonts/proxima-nova/ProximaNova-Extrabld.svg',
    'ProximaNova-Extrabld__ttf' => 'http://envato.pixevil.com/volta/resources/fonts/proxima-nova/ProximaNova-Extrabld.ttf',
    'ProximaNova-Extrabld__woff' => 'http://envato.pixevil.com/volta/resources/fonts/proxima-nova/ProximaNova-Extrabld.woff',
    'ProximaNova-Extrabld__woff2' => 'http://envato.pixevil.com/volta/resources/fonts/proxima-nova/ProximaNova-Extrabld.woff2',
    'ProximaNova-Light__svg' => 'http://envato.pixevil.com/volta/resources/fonts/proxima-nova/ProximaNova-Light.svg',
    'ProximaNova-Light__ttf' => 'http://envato.pixevil.com/volta/resources/fonts/proxima-nova/ProximaNova-Light.ttf',
    'ProximaNova-Light__woff' => 'http://envato.pixevil.com/volta/resources/fonts/proxima-nova/ProximaNova-Light.woff',
    'ProximaNova-Light__woff2' => 'http://envato.pixevil.com/volta/resources/fonts/proxima-nova/ProximaNova-Light.woff2',
    'ProximaNova-Regular__svg' => 'http://envato.pixevil.com/volta/resources/fonts/proxima-nova/ProximaNova-Regular.svg',
    'ProximaNova-Regular__ttf' => 'http://envato.pixevil.com/volta/resources/fonts/proxima-nova/ProximaNova-Regular.ttf',
    'ProximaNova-Regular__woff' => 'http://envato.pixevil.com/volta/resources/fonts/proxima-nova/ProximaNova-Regular.woff',
    'ProximaNova-Regular__woff2' => 'http://envato.pixevil.com/volta/resources/fonts/proxima-nova/ProximaNova-Regular.woff2',
    'ProximaNova-Semibold__svg' => 'http://envato.pixevil.com/volta/resources/fonts/proxima-nova/ProximaNova-Semibold.svg',
    'ProximaNova-Semibold__ttf' => 'http://envato.pixevil.com/volta/resources/fonts/proxima-nova/ProximaNova-Semibold.ttf',
    'ProximaNova-Semibold__woff' => 'http://envato.pixevil.com/volta/resources/fonts/proxima-nova/ProximaNova-Semibold.woff',
    'ProximaNova-Semibold__woff2' => 'http://envato.pixevil.com/volta/resources/fonts/proxima-nova/ProximaNova-Semibold.woff2',
    'ProximaNova-Thin__svg' => 'http://envato.pixevil.com/volta/resources/fonts/proxima-nova/ProximaNova-Thin.svg',
    'ProximaNova-Thin__ttf' => 'http://envato.pixevil.com/volta/resources/fonts/proxima-nova/ProximaNova-Thin.ttf',
    'ProximaNova-Thin__woff' => 'http://envato.pixevil.com/volta/resources/fonts/proxima-nova/ProximaNova-Thin.woff',
    'ProximaNova-Thin__woff2' => 'http://envato.pixevil.com/volta/resources/fonts/proxima-nova/ProximaNova-Thin.woff2',
    'fontawesome-webfont__eot' => 'http://envato.pixevil.com/volta/vendors/font-awesome/fonts/fontawesome-webfont.eot',
    'fontawesome-webfont__eot' => 'http://envato.pixevil.com/volta/vendors/font-awesome/fonts/fontawesome-webfont.eot',
    'fontawesome-webfont__svg' => 'http://envato.pixevil.com/volta/vendors/font-awesome/fonts/fontawesome-webfont.svg',
    'fontawesome-webfont__ttf' => 'http://envato.pixevil.com/volta/vendors/font-awesome/fonts/fontawesome-webfont.ttf',
    'fontawesome-webfont__woff2' => 'http://envato.pixevil.com/volta/vendors/font-awesome/fonts/fontawesome-webfont.woff2',
    'fontawesome-webfont__woff' => 'http://envato.pixevil.com/volta/vendors/font-awesome/fonts/fontawesome-webfont.woff',
    'Pe-icon-7-stroke__eot' => 'http://envato.pixevil.com/volta/vendors/pixeden-stroke/fonts/Pe-icon-7-stroke.eot',
    'Pe-icon-7-stroke__eot' => 'http://envato.pixevil.com/volta/vendors/pixeden-stroke/fonts/Pe-icon-7-stroke.eot',
    'Pe-icon-7-stroke__svg' => 'http://envato.pixevil.com/volta/vendors/pixeden-stroke/fonts/Pe-icon-7-stroke.svg',
    'Pe-icon-7-stroke__ttf' => 'http://envato.pixevil.com/volta/vendors/pixeden-stroke/fonts/Pe-icon-7-stroke.ttf',
    'Pe-icon-7-stroke__woff' => 'http://envato.pixevil.com/volta/vendors/pixeden-stroke/fonts/Pe-icon-7-stroke.woff',
    'summernote__eot' => 'http://envato.pixevil.com/volta/vendors/summernote/fonts/summernote.eot',
    'summernote__eot' => 'http://envato.pixevil.com/volta/vendors/summernote/fonts/summernote.eot',
    'summernote__ttf' => 'http://envato.pixevil.com/volta/vendors/summernote/fonts/summernote.ttf',
    'summernote__woff' => 'http://envato.pixevil.com/volta/vendors/summernote/fonts/summernote.woff',
    'ProximaNova-Bold__eot' => 'http://envato.pixevil.com/volta/resources/fonts/proxima-nova/ProximaNova-Bold.eot',
    'ProximaNova-Extrabld__eot' => 'http://envato.pixevil.com/volta/resources/fonts/proxima-nova/ProximaNova-Extrabld.eot',
    'ProximaNova-Light__eot' => 'http://envato.pixevil.com/volta/resources/fonts/proxima-nova/ProximaNova-Light.eot',
    'ProximaNova-Regular__eot' => 'http://envato.pixevil.com/volta/resources/fonts/proxima-nova/ProximaNova-Regular.eot',
    'ProximaNova-Semibold__eot' => 'http://envato.pixevil.com/volta/resources/fonts/proxima-nova/ProximaNova-Semibold.eot',
    'ProximaNova-Thin__eot' => 'http://envato.pixevil.com/volta/resources/fonts/proxima-nova/ProximaNova-Thin.eot',
);

$texto = '';
foreach ($master as $title => $url) {
    $i = 1;
    $extension = explode('.', $url);
    $ch = curl_init(trim($url));

    //**********************//
    // FIX FOR TITLE HANDLE //
    //**********************//
    $realtitle = explode('__', $title);
    $title = $realtitle[0];

    $fp = fopen('getfiles/' . trim($title) . '.' . trim(end($extension)), 'wb');
    curl_setopt($ch, CURLOPT_FILE, $fp);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_exec($ch);
    curl_close($ch);
    fclose($fp);
    $i++;
    $texto .= ' descargado: ' . $url . ' <br />';
}


echo $texto . '<br /> Script finalizado';
