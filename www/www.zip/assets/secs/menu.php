<!-- MENU SIDEBARS-->
<div class="sidebar -dark -left -slideable" id="sidebar">
    <div class="scrollable">
        <div class="scrollable-content">
            <div class="sidebar-wrapper">
                <ul class="sidebar-menu metismenu">
                    <li class="sidebar-heading"> Universe</li>
                    <li gotopanel='home' class="-active active gotobtn"><a href="index.php"> <i class="pe pe-home"></i><span> Inicio</span></a></li>
                </ul>
            </div>
        </div>
    </div>
</div>