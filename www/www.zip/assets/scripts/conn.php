<?php

////////////////////////////////////////////////////////////////////////////////////DEBUG EN PANTALLA
//error_reporting(E_ALL);
//ini_set('display_errors', 1);

//// Conexion a la base de datos LOCAL
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASSWORD', 'vagrant');
define('DB_DATABASE', 'universe');

// Conexion a la base de datos CLOUD BURTONSERVERS.COM
//define('DB_HOST', 'localhost');
//define('DB_USER', 'homecubi_root');
//define('DB_PASSWORD', 'UzbMZ;9?@hU6');
//define('DB_DATABASE', 'homecubi_homecubic');



//CONEXION A DB
$dblink = mysqli_connect(DB_HOST, DB_USER, DB_PASSWORD, DB_DATABASE);
if (!$dblink) {
    echo "Error: Unable to connect to MySQL." . PHP_EOL;
    echo "Debugging errno: " . mysqli_connect_errno() . PHP_EOL;
    echo "Debugging error: " . mysqli_connect_error() . PHP_EOL;
    exit;
}
?>