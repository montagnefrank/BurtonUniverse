<?php

$r = rand(1, 2);
switch ($r) {
    case 1:
        $video = "wTeKnXaOmjg";
        $color = "white";
        break;
    case 2:
        $video = "7hiLrRaC2Ps";
        $color = "white";
        break;
    case 3:
        $video = "PtsrQb7_RLo";
        $color = "white";
        break;
    case 4:
        $video = "RCZPsCjAbEU";
        $color = "white";
        break;
    case 5:
        $video = "CID60MMXLbA";
        $color = "solid";
        break;
    case 6:
        $video = "mEqcala-NiE";
        $color = "white";
        break;
    case 7:
        $video = "O5x4VNwRYAQ";
        $color = "solid";
        break;
    case 8:
        $video = "s7MaoPjGYdA";
        $color = "purple";
        break;
}
//$video = "7hiLrRaC2Ps";
//$color = "white";
?>