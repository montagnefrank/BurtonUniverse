<div class="content -dark -with-left-sidebar -collapsible">
    <div class="container-fluid">
        <div class="breadcrumb -dark">
            <a class="breadcrumb-item" href="#"><i class="fa fa-home"> </i></a>
            <a  gotopanel='home' class="breadcrumb-item gotobtn" href="#">Universe</a>
            <div class="breadcrumb-item -active">Inicio</div>
        </div>
    </div>
</div>