<div class="content -dark -with-left-sidebar -collapsible">
    <div class="container-fluid">

        <?php // BREADCRUMBS ?>
        <div class="breadcrumb -dark">
            <a class="breadcrumb-item" href="#"><i class="fa fa-home"> </i></a>
            <a gotopanel='home' class="breadcrumb-item gotobtn" href="#">Universe</a>
            <div class="breadcrumb-item -active"> Configuraci&oacute;n de la cuenta</div>
        </div>

        <?php // EDITAR DATOS FORM ?>
        <div class="row">

        </div>
        <div class="col -lg-8">
            <div class="panel -dark">
                <div class="panel-heading -with-icon-lg"><i class="fa fa-edit"> </i>
                    <h4>Editar informaci&oacute;n de la cuenta</h4><span> aqu&iacute; puede actualizar los datos de su cuenta</span>
                </div>
                <div class="panel-body">
                    <div class="col -lg-3">
                        <div class="panel -dark">
                            <div class="panel-body">
                                <img class="-responsive -round _margin-1x" src="http://placehold.it/135x135" alt="Volta Admin Dashboard">
                            </div>
                        </div>
                    </div>

                    <div class="col -lg-3">
                        <div class="panel -dark">
                            <div class="panel-body">
                                <!--<input  class="fileinput btn-info" type="file" name="testinput" id="testinput" title="Buscar Imagen">-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col -lg-3">
            <div class="panel -dark">
                <div class="panel-heading -with-icon-lg"><i class="fa fa-edit"> </i>
                    <h4>Editar informaci&oacute;n de la cuenta</h4><span> aqu&iacute; puede actualizar los datos de su cuenta</span>
                </div>
                <div class="panel-body">
                    <div class="col -lg-3">
                        <div class="panel -dark">
                            <div class="panel-body">
                                <img class="-responsive -round _margin-1x" src="http://placehold.it/135x135" alt="Volta Admin Dashboard">
                            </div>
                        </div>
                    </div>

                    <div class="col -lg-3">
                        <div class="panel -dark">
                            <div class="panel-body">
                                <!--<input  class="fileinput btn-info" type="file" name="testinput" id="testinput" title="Buscar Imagen">-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>