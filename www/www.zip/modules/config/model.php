<?php

/////////////////////////////////////////////////////////////////////////////// PORTFOLIO MODEL

?>

<script>

    $("#testinput").fileinput({
        showUpload: false,
        showCaption: false,
        browseClass: "btn btn-info",
        fileType: "jpg"
    });
    
</script>