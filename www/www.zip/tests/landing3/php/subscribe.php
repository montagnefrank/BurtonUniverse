<?php
///////////////////////////////////////////////////////////////////////////////////////////DEBUG EN PANTALLA
error_reporting(E_ALL);
ini_set('display_errors', 1);

require ("../assets/conn.php");

$sel = "SELECT subscriber FROM newsletter WHERE subscriber = '". $_POST["email"] ."' LIMIT 1 ";
$res = $conn->query($sel);
if (!$res) {
        $res = 'Error al ingresar. ' . $conn->error;
        echo $res;
    } else {
        $row = $res->fetch_array(MYSQLI_BOTH);
    }
if ($row[0] != '') {////////////////////////////////////////////////////////////SI EL CORRE YA EXISTE
    echo "Tu email ya se encuentra en nuestro sistema.<br> Te informaremos apenas demos inicio.";
} else {
    $sel = "INSERT INTO newsletter (subscriber) VALUES ('". $_POST["email"] ."')";
    $res = $conn->query($sel);
    echo "Felicitaciones! Ahora dominar&aacute;s la tecnolog&iacute;a como nadie.<br>Te informaremos apenas demos inicio.";
}

die;