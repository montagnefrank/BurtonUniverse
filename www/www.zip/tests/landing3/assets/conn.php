<?php
///////////////////////////////////////////////////////////////////////////////////////////DEBUG EN PANTALLA
//error_reporting(E_ALL);
//ini_set('display_errors', 1);

// Conexion a la base de datos
define('DB_HOST', 'localhost');
define('DB_USER', 'c0280420_burton');
define('DB_PASSWORD', 'Burton1234');	
define('DB_DATABASE', 'c0280420_burton');

$conn = new mysqli(DB_HOST,DB_USER,DB_PASSWORD,DB_DATABASE);
mysqli_set_charset($conn,"utf8");
if($conn->connect_error)
{
    echo "No se puede establecer la conexión con la BDD dirulo";
} 